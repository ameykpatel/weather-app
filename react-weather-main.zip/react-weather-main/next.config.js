module.exports = {
  reactStrictMode: true
};
